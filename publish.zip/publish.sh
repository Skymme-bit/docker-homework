#!/bin/bash

set -e

if [ $# -ne 1 ]; then
  echo "You must provide your Docker Hub username as a parameter."
  echo "Usage: ./publish.sh <username>"
  exit 1
fi

DOCKER_USERNAME=$1
IMAGE_NAME="docker-homework"

echo "Building backend Docker image..."
docker build -t $DOCKER_USERNAME/$IMAGE_NAME-backend:latest -f backend/Dockerfile ./backend

echo "Tagging and publishing backend image..."
docker push $DOCKER_USERNAME/$IMAGE_NAME-backend:latest

echo "Building frontend Docker image..."
docker build -t $DOCKER_USERNAME/$IMAGE_NAME-frontend:latest -f frontend/Dockerfile ./frontend

echo "Tagging and publishing frontend image..."
docker push $DOCKER_USERNAME/$IMAGE_NAME-frontend:latest

echo "✅ Successfully built and pushed backend and frontend images to Docker Hub!"
